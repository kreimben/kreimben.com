'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'truck-ramp-box';
var width = 640;
var height = 512;
var aliases = ["truck-loading"];
var unicode = 'f4de';
var svgPathData = 'M640 .0003V400C640 461.9 589.9 512 528 512C467 512 417.5 463.3 416 402.7L48.41 502.9C31.36 507.5 13.77 497.5 9.126 480.4C4.48 463.4 14.54 445.8 31.59 441.1L352 353.8V64C352 28.65 380.7 0 416 0L640 .0003zM528 352C501.5 352 480 373.5 480 400C480 426.5 501.5 448 528 448C554.5 448 576 426.5 576 400C576 373.5 554.5 352 528 352zM23.11 207.7C18.54 190.6 28.67 173.1 45.74 168.5L92.1 156.1L112.8 233.4C115.1 241.9 123.9 246.1 132.4 244.7L163.3 236.4C171.8 234.1 176.9 225.3 174.6 216.8L153.9 139.5L200.3 127.1C217.4 122.5 234.9 132.7 239.5 149.7L280.9 304.3C285.5 321.4 275.3 338.9 258.3 343.5L103.7 384.9C86.64 389.5 69.1 379.3 64.52 362.3L23.11 207.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTruckRampBox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;