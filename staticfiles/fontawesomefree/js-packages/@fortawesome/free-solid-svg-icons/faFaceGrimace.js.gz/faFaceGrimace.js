'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'face-grimace';
var width = 512;
var height = 512;
var aliases = [128556,"grimace"];
var unicode = 'f57f';
var svgPathData = 'M0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256zM399.3 360H344V400H352C375.8 400 395.5 382.7 399.3 360zM352 304H344V344H399.3C395.5 321.3 375.8 304 352 304zM328 344V304H264V344H328zM328 400V360H264V400H328zM184 304V344H248V304H184zM184 360V400H248V360H184zM168 344V304H160C136.2 304 116.5 321.3 112.7 344H168zM168 400V360H112.7C116.5 382.7 136.2 400 160 400H168zM176.4 176C158.7 176 144.4 190.3 144.4 208C144.4 225.7 158.7 240 176.4 240C194 240 208.4 225.7 208.4 208C208.4 190.3 194 176 176.4 176zM336.4 240C354 240 368.4 225.7 368.4 208C368.4 190.3 354 176 336.4 176C318.7 176 304.4 190.3 304.4 208C304.4 225.7 318.7 240 336.4 240z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFaceGrimace = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;