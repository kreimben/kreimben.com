'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'suitcase';
var width = 512;
var height = 512;
var aliases = [129523];
var unicode = 'f0f2';
var svgPathData = 'M128 56C128 25.07 153.1 0 184 0H328C358.9 0 384 25.07 384 56V480H128V56zM176 96H336V56C336 51.58 332.4 48 328 48H184C179.6 48 176 51.58 176 56V96zM64 96H96V480H64C28.65 480 0 451.3 0 416V160C0 124.7 28.65 96 64 96zM448 480H416V96H448C483.3 96 512 124.7 512 160V416C512 451.3 483.3 480 448 480z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSuitcase = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;