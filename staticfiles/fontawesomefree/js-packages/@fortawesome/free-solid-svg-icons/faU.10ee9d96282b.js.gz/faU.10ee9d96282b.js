'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'u';
var width = 384;
var height = 512;
var aliases = [117];
var unicode = '55';
var svgPathData = 'M384 64.01v225.7c0 104.1-86.13 190.3-192 190.3s-192-85.38-192-190.3V64.01C0 46.34 14.33 32.01 32 32.01S64 46.34 64 64.01v225.7c0 69.67 57.42 126.3 128 126.3s128-56.67 128-126.3V64.01c0-17.67 14.33-32 32-32S384 46.34 384 64.01z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faU = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;