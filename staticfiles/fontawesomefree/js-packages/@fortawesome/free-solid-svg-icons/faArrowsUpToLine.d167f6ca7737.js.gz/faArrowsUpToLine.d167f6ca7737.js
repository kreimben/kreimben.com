'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrows-up-to-line';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e4c2';
var svgPathData = 'M32 96C14.33 96 0 81.67 0 64C0 46.33 14.33 32 32 32H544C561.7 32 576 46.33 576 64C576 81.67 561.7 96 544 96H32zM105.4 137.4C117.9 124.9 138.1 124.9 150.6 137.4L246.6 233.4C259.1 245.9 259.1 266.1 246.6 278.6C234.1 291.1 213.9 291.1 201.4 278.6L160 237.3V448C160 465.7 145.7 480 128 480C110.3 480 96 465.7 96 448V237.3L54.63 278.6C42.13 291.1 21.87 291.1 9.372 278.6C-3.124 266.1-3.124 245.9 9.372 233.4L105.4 137.4zM329.4 233.4L425.4 137.4C437.9 124.9 458.1 124.9 470.6 137.4L566.6 233.4C579.1 245.9 579.1 266.1 566.6 278.6C554.1 291.1 533.9 291.1 521.4 278.6L480 237.3L480 448C480 465.7 465.7 480 448 480C430.3 480 416 465.7 416 448V237.3L374.6 278.6C362.1 291.1 341.9 291.1 329.4 278.6C316.9 266.1 316.9 245.9 329.4 233.4H329.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsUpToLine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;