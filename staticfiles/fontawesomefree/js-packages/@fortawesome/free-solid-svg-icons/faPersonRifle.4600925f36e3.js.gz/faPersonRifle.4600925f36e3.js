'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'person-rifle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e54e';
var svgPathData = 'M265.2 192C290.6 192 315 199.1 336 211.9V512H144V337.7L90.44 428.3C79.21 447.4 54.68 453.7 35.66 442.4C16.64 431.2 10.33 406.7 21.57 387.7L97.7 258.8C122.2 217.4 166.7 192 214.8 192L265.2 192zM320 80C320 124.2 284.2 160 240 160C195.8 160 160 124.2 160 80C160 35.82 195.8 .0003 240 .0003C284.2 .0003 320 35.82 320 80zM464 16V132.3C473.6 137.8 480 148.2 480 160V269.3L496 264V208C496 199.2 503.2 192 512 192H528C536.8 192 544 199.2 544 208V292.5C544 299.4 539.6 305.5 533.1 307.6L480 325.3V352H528C536.8 352 544 359.2 544 368V384C544 392.8 536.8 400 528 400H484L507 492.1C509.6 502.2 501.9 512 491.5 512H432C423.2 512 416 504.8 416 496V400H400C382.3 400 368 385.7 368 368V224C368 206.3 382.3 192 400 192V160C400 148.2 406.4 137.8 416 132.3V32C407.2 32 400 24.84 400 16C400 7.164 407.2 0 416 0H448C456.8 0 464 7.164 464 16V16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPersonRifle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;