'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cable-car';
var width = 512;
var height = 512;
var aliases = [128673,57551,"tram"];
var unicode = 'f7da';
var svgPathData = 'M256 32C256 14.33 270.3 0 288 0C305.7 0 320 14.33 320 32C320 49.67 305.7 64 288 64C270.3 64 256 49.67 256 32zM224 56C224 73.67 209.7 88 192 88C174.3 88 160 73.67 160 56C160 38.33 174.3 24 192 24C209.7 24 224 38.33 224 56zM32 288C32 252.7 60.65 224 96 224H232V157.5L28.86 199.5C15.88 202.2 3.183 193.8 .4976 180.9C-2.188 167.9 6.157 155.2 19.14 152.5L483.1 56.5C496.1 53.81 508.8 62.16 511.5 75.14C514.2 88.12 505.8 100.8 492.9 103.5L280 147.5V224H416C451.3 224 480 252.7 480 288V448C480 483.3 451.3 512 416 512H96C60.65 512 32 483.3 32 448V288zM96 288C87.16 288 80 295.2 80 304V368C80 376.8 87.16 384 96 384H160C168.8 384 176 376.8 176 368V304C176 295.2 168.8 288 160 288H96zM208 368C208 376.8 215.2 384 224 384H288C296.8 384 304 376.8 304 368V304C304 295.2 296.8 288 288 288H224C215.2 288 208 295.2 208 304V368zM352 288C343.2 288 336 295.2 336 304V368C336 376.8 343.2 384 352 384H416C424.8 384 432 376.8 432 368V304C432 295.2 424.8 288 416 288H352z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCableCar = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;