'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'tent-arrow-left-right';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e57f';
var svgPathData = 'M568.1 78.16C573.1 82.71 576 89.2 576 96C576 102.8 573.1 109.3 568.1 113.8L488.1 185.8C478.2 194.7 463 193.9 454.2 184.1C445.3 174.2 446.1 159 455.9 150.2L489.5 120H86.54L120.1 150.2C129.9 159 130.7 174.2 121.8 184.1C112.1 193.9 97.8 194.7 87.94 185.8L7.945 113.8C2.888 109.3 0 102.8 0 96C0 89.2 2.888 82.71 7.945 78.16L87.94 6.161C97.8-2.706 112.1-1.907 121.8 7.945C130.7 17.8 129.9 32.97 120.1 41.84L86.54 72H489.5L455.9 41.84C446.1 32.97 445.3 17.8 454.2 7.945C463-1.907 478.2-2.706 488.1 6.161L568.1 78.16zM475.4 294.5C482 299.6 486.4 307 487.6 315.3L511.6 475.3C513 484.5 510.3 493.8 504.2 500.9C498.2 507.9 489.3 512 480 512H384L287.1 352V512H96C86.68 512 77.83 507.9 71.75 500.9C65.67 493.8 62.97 484.5 64.35 475.3L88.35 315.3C89.59 307 93.98 299.6 100.6 294.5L268.6 166.5C280.1 157.8 295.9 157.8 307.4 166.5L475.4 294.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTentArrowLeftRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;