'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'synagogue';
var width = 640;
var height = 512;
var aliases = [128333];
var unicode = 'f69b';
var svgPathData = 'M309.8 3.708C315.7-1.236 324.3-1.236 330.2 3.708L451.2 104.5C469.5 119.7 480 142.2 480 165.1V512H384V384C384 348.7 355.3 320 320 320C284.7 320 256 348.7 256 384V512H160V165.1C160 142.2 170.5 119.7 188.8 104.5L309.8 3.708zM326.1 124.3C323.9 118.9 316.1 118.9 313 124.3L297.2 152.4L264.9 152.1C258.7 152.1 254.8 158.8 257.9 164.2L274.3 191.1L257.9 219.8C254.8 225.2 258.7 231.9 264.9 231.9L297.2 231.6L313 259.7C316.1 265.1 323.9 265.1 326.1 259.7L342.8 231.6L375.1 231.9C381.3 231.9 385.2 225.2 382.1 219.8L365.7 191.1L382.1 164.2C385.2 158.8 381.3 152.1 375.1 152.1L342.8 152.4L326.1 124.3zM512 244.5L540.1 213.3C543.1 209.9 547.5 208 552 208C556.5 208 560.9 209.9 563.9 213.3L627.7 284.2C635.6 292.1 640 304.4 640 316.3V448C640 483.3 611.3 512 576 512H512V244.5zM128 244.5V512H64C28.65 512 0 483.3 0 448V316.3C0 304.4 4.389 292.1 12.32 284.2L76.11 213.3C79.14 209.9 83.46 208 88 208C92.54 208 96.86 209.9 99.89 213.3L128 244.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSynagogue = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;