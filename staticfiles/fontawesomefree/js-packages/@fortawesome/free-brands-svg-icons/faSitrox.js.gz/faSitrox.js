'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'sitrox';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e44a';
var svgPathData = 'M212.4 .0085V0H448V128H64C64 57.6 141.8 .4753 212.4 .0085zM237.3 192V192C307.1 192.5 384 249.6 384 320H210.8V319.1C140.9 319.6 64 262.4 64 192H237.3zM235.6 511.1C306.3 511.5 384 454.4 384 384H0V512H235.6V511.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSitrox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;