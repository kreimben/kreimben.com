'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'wodu';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e088';
var svgPathData = 'M178.4 339.7H141.1L112.2 223.5h-.478L83.23 339.7H45.2L0 168.9H37.55L64.57 285.2h.478L94.71 168.9h35.16l29.18 117.7h.479L187.5 168.9h36.83zM271.4 212.7c38.98 0 64.1 25.83 64.1 65.29 0 39.22-25.11 65.05-64.1 65.05-38.74 0-63.85-25.83-63.85-65.05C207.5 238.5 232.7 212.7 271.4 212.7zm0 104.8c23.2 0 30.13-19.85 30.13-39.46 0-19.85-6.934-39.7-30.13-39.7-27.7 0-29.89 19.85-29.89 39.7C241.5 297.6 248.4 317.5 271.4 317.5zM435.1 323.9h-.478c-7.893 13.39-21.76 19.13-37.55 19.13-37.31 0-55.49-32.04-55.49-66.25 0-33.24 18.42-64.1 54.77-64.1 14.59 0 28.94 6.218 36.83 18.42h.24V168.9h33.96v170.8H435.1zM405.4 238.3c-22.24 0-29.89 19.13-29.89 39.46 0 19.37 8.848 39.7 29.89 39.7 22.48 0 29.18-19.61 29.18-39.94C434.6 257.4 427.4 238.3 405.4 238.3zM592.1 339.7H560.7V322.5h-.718c-8.609 13.87-23.44 20.57-37.79 20.57-36.11 0-45.2-20.33-45.2-50.94V216.1h33.96V285.9c0 20.33 5.979 30.37 21.76 30.37 18.42 0 26.31-10.28 26.31-35.39V216.1H592.1zM602.5 302.9H640v36.83H602.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWodu = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;