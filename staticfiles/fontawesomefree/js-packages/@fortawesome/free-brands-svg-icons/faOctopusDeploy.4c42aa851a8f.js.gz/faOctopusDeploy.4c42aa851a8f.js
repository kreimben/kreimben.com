'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'octopus-deploy';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e082';
var svgPathData = 'M455.6 349.2c-45.89-39.09-36.67-77.88-16.09-128.1C475.2 134 415.1 34.14 329.9 8.3 237-19.6 134.3 24.34 99.68 117.1a180.9 180.9 0 0 0 -10.99 73.54c1.733 29.54 14.72 52.97 24.09 80.3 17.2 50.16-28.1 92.74-66.66 117.6-46.81 30.2-36.32 39.86-8.428 41.86 23.38 1.68 44.48-4.548 65.26-15.05 9.2-4.647 40.69-18.93 45.13-28.59C135.9 413.4 111.1 459.5 126.6 488.9c19.1 36.23 67.11-31.77 76.71-45.81 8.591-12.57 42.96-81.28 63.63-46.93 18.86 31.36 8.6 76.39 35.74 104.6 32.85 34.2 51.15-18.31 51.41-44.22 .163-16.41-6.1-95.85 29.9-59.94C405.4 418 436.9 467.8 472.6 463.6c38.74-4.516-22.12-67.97-28.26-78.69 5.393 4.279 53.67 34.13 53.82 9.52C498.2 375.7 468 359.8 455.6 349.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faOctopusDeploy = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;