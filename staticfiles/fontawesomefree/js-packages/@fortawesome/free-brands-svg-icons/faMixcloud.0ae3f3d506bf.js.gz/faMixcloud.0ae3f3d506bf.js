'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'mixcloud';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f289';
var svgPathData = 'M212.1 346.6H179.8V195.1L185.1 173.5H175.3L137.1 346.6H76.11L37.73 173.5H27.28L33.19 195.1V346.6H0V165H65.65L102.2 338.1H110.7L147.3 165H212.1L212.1 346.6zM544.5 283.6L458.4 345.7V307.5L531.3 255.8L458.4 204V165.9L544.5 228.2H553.7L640 165.9V204L566.9 255.8L640 307.5V345.7L553.7 283.6H544.5zM430.2 272.3H248.1V239.3H430.2V272.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMixcloud = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;