'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'hive';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e07f';
var svgPathData = 'M260.4 254.9 131.5 33.1a2.208 2.208 0 0 0 -3.829 .009L.3 254.9A2.234 2.234 0 0 0 .3 257.1L129.1 478.9a2.208 2.208 0 0 0 3.83-.009L260.4 257.1A2.239 2.239 0 0 0 260.4 254.9zm39.08-25.71a2.19 2.19 0 0 0 1.9 1.111h66.51a2.226 2.226 0 0 0 1.9-3.341L259.1 33.11a2.187 2.187 0 0 0 -1.9-1.111H190.7a2.226 2.226 0 0 0 -1.9 3.341zM511.7 254.9 384.9 33.11A2.2 2.2 0 0 0 382.1 32h-66.6a2.226 2.226 0 0 0 -1.906 3.34L440.7 256 314.5 476.7a2.226 2.226 0 0 0 1.906 3.34h66.6a2.2 2.2 0 0 0 1.906-1.112L511.7 257.1A2.243 2.243 0 0 0 511.7 254.9zM366 284.9H299.5a2.187 2.187 0 0 0 -1.9 1.111l-108.8 190.6a2.226 2.226 0 0 0 1.9 3.341h66.51a2.187 2.187 0 0 0 1.9-1.111l108.8-190.6A2.226 2.226 0 0 0 366 284.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faHive = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;