'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'shopware';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f5b5';
var svgPathData = 'M403.5 455.4A246.2 246.2 0 0 1 256 504C118.8 504 8 393 8 256 8 118.8 119 8 256 8a247.4 247.4 0 0 1 165.7 63.5 3.57 3.57 0 0 1 -2.86 6.18A418.6 418.6 0 0 0 362.1 74c-129.4 0-222.4 53.47-222.4 155.4 0 109 92.13 145.9 176.8 178.7 33.64 13 65.4 25.36 87 41.59a3.58 3.58 0 0 1 0 5.72zM503 233.1a3.64 3.64 0 0 0 -1.27-2.44c-51.76-43-93.62-60.48-144.5-60.48-84.13 0-80.25 52.17-80.25 53.63 0 42.6 52.06 62 112.3 84.49 31.07 11.59 63.19 23.57 92.68 39.93a3.57 3.57 0 0 0 5-1.82A249 249 0 0 0 503 233.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faShopware = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;