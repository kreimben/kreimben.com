'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'linode';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f2b8';
var svgPathData = 'M366 186.9l-59.5 36.87-.838 36.87-29.33-19.27-39.38 24.3c2.238 55.21 2.483 59.27 2.51 59.5l-97.2 65.36L127.2 285.7l108.1-62.01L195.1 197.8l-75.42 38.55L98.72 93.01 227.8 43.57 136.4 0 10.74 39.38 38.39 174.3l41.9 32.68L48.44 222.1 69.39 323.5 98.72 351.1 77.77 363.7l16.76 78.77L160.7 512c-10.8-74.84-11.66-78.64-11.73-78.77l77.93-55.3c16.76-12.57 15.08-10.89 15.08-10.89l.838 24.3 33.52 28.49-.838-77.09 46.93-33.52 26.82-18.43-2.514 36.03 25.14 17.6 6.7-74.58 58.66-43.58z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faLinode = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;