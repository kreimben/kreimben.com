'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'vk';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f189';
var svgPathData = 'M31.49 63.49C0 94.98 0 145.7 0 247V264.1C0 366.3 0 417 31.49 448.5C62.98 480 113.7 480 215 480H232.1C334.3 480 385 480 416.5 448.5C448 417 448 366.3 448 264.1V247C448 145.7 448 94.98 416.5 63.49C385 32 334.3 32 232.1 32H215C113.7 32 62.98 32 31.49 63.49zM75.6 168.3H126.7C128.4 253.8 166.1 289.1 196 297.4V168.3H244.2V242C273.7 238.8 304.6 205.2 315.1 168.3H363.3C359.3 187.4 351.5 205.6 340.2 221.6C328.9 237.6 314.5 251.1 297.7 261.2C316.4 270.5 332.9 283.6 346.1 299.8C359.4 315.9 369 334.6 374.5 354.7H321.4C316.6 337.3 306.6 321.6 292.9 309.8C279.1 297.9 262.2 290.4 244.2 288.1V354.7H238.4C136.3 354.7 78.03 284.7 75.6 168.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faVk = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;