'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'guilded';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e07e';
var svgPathData = 'M443.4 64H4.571c0 103.3 22.19 180.1 43.42 222.4C112 414.1 224 448 225.3 448a312.8 312.8 0 0 0 140.6-103.5c25.91-33.92 53.1-87.19 65.92-145.8H171.8c4.14 36.43 22.18 67.95 45.1 86.94h88.59c-17.01 28.21-48.19 54.4-80.46 69.48-31.23-13.26-69.09-46.54-96.55-98.36-26.73-53.83-27.09-105.9-27.09-105.9H437.6A625.9 625.9 0 0 0 443.4 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGuilded = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;