'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'qq';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f1d6';
var svgPathData = 'M433.8 420.4c-11.53 1.393-44.86-52.74-44.86-52.74 0 31.34-16.14 72.25-51.05 101.8 16.84 5.192 54.84 19.17 45.8 34.42-7.316 12.34-125.5 7.881-159.6 4.037-34.12 3.844-152.3 8.306-159.6-4.037-9.045-15.25 28.92-29.21 45.78-34.42-34.92-29.54-51.06-70.44-51.06-101.8 0 0-33.33 54.13-44.86 52.74-5.37-.65-12.42-29.64 9.347-99.7 10.26-33.02 21.1-60.48 40.14-105.8C60.68 98.06 108.1 .006 224 0c113.7 .006 163.2 96.13 160.3 214.1 18.12 45.22 29.91 72.85 40.14 105.8 21.77 70.06 14.72 99.05 9.346 99.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faQq = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;